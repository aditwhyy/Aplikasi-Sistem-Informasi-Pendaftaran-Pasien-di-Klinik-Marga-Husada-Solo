-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 18, 2024 at 04:40 PM
-- Server version: 10.9.2-MariaDB
-- PHP Version: 8.0.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbmargahusada`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_daftar_pasien`
--

CREATE TABLE `tb_daftar_pasien` (
  `id` int(11) NOT NULL,
  `id_pasien` int(11) NOT NULL,
  `id_dokter` int(11) DEFAULT NULL,
  `id_spesialis` int(11) NOT NULL,
  `keluhan` text DEFAULT NULL,
  `tanggal_daftar` date NOT NULL,
  `cara_bayar` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_daftar_pasien`
--

INSERT INTO `tb_daftar_pasien` (`id`, `id_pasien`, `id_dokter`, `id_spesialis`, `keluhan`, `tanggal_daftar`, `cara_bayar`) VALUES
(1, 22, 2, 13, 'demam', '2024-06-18', 'umum'),
(2, 23, NULL, 13, NULL, '2024-06-18', NULL),
(3, 24, NULL, 13, NULL, '1975-07-14', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_dokter`
--

CREATE TABLE `tb_dokter` (
  `id_dokter` int(11) NOT NULL,
  `nama_d` varchar(50) NOT NULL,
  `id_spesialis` int(11) NOT NULL,
  `jam_praktek` varchar(20) NOT NULL,
  `jenis_kelamin_d` enum('laki-laki','perempuan') NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_dokter`
--

INSERT INTO `tb_dokter` (`id_dokter`, `nama_d`, `id_spesialis`, `jam_praktek`, `jenis_kelamin_d`, `tanggal`) VALUES
(1, 'dr. Dini Nurul Annisa', 13, '08:00 - 11:00', 'perempuan', '2020-03-01'),
(2, 'dr. Ramon Otto Andinata', 13, '14:00 - 18:00', 'laki-laki', '2020-02-01'),
(3, 'dr. R. Iwan Wahyu U', 13, '18:00 - 20:30', 'laki-laki', '2020-03-02');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pasien`
--

CREATE TABLE `tb_pasien` (
  `id_pasien` int(11) NOT NULL,
  `norm` varchar(11) NOT NULL,
  `nik` varchar(16) DEFAULT NULL,
  `nama_p` varchar(50) NOT NULL,
  `umur_p` int(5) NOT NULL,
  `tanggal_lahir_p` date NOT NULL,
  `alamat_p` text NOT NULL,
  `notelp_p` varchar(15) NOT NULL,
  `jenis_kelamin_p` enum('laki-laki','perempuan') NOT NULL,
  `kota_p` text NOT NULL,
  `tanggal` date NOT NULL,
  `terverifikasi` tinyint(1) NOT NULL DEFAULT 1,
  `daftar_online` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_pasien`
--

INSERT INTO `tb_pasien` (`id_pasien`, `norm`, `nik`, `nama_p`, `umur_p`, `tanggal_lahir_p`, `alamat_p`, `notelp_p`, `jenis_kelamin_p`, `kota_p`, `tanggal`, `terverifikasi`, `daftar_online`) VALUES
(22, 'RM000001', '3312160501030002', 'adit', 21, '2003-01-05', 'wonogiri', '', 'laki-laki', '', '0000-00-00', 1, 0),
(23, 'RM000002', '1331214214', 'uji coba', 21, '2024-06-18', 'sasas', '', 'laki-laki', '', '0000-00-00', 0, 0),
(24, 'RM000003', '76', 'Adipisicing dolor se', 25, '2002-04-10', 'Ipsam consequatur I', '', 'laki-laki', '', '0000-00-00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_spesialis`
--

CREATE TABLE `tb_spesialis` (
  `id_spesialis` int(11) NOT NULL,
  `nama_spesialis` varchar(50) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_spesialis`
--

INSERT INTO `tb_spesialis` (`id_spesialis`, `nama_spesialis`, `tanggal`) VALUES
(13, 'Poli Umum', '2024-06-18'),
(14, 'Poli Gigi', '2024-06-18'),
(15, 'Khitan/Sunat', '2024-06-18'),
(16, 'Fisioterapi Pijat Bayi', '2024-06-18'),
(17, 'Vaksin Umroh', '2024-06-18');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `nama_u` varchar(50) NOT NULL,
  `jenis_kelamin_u` enum('laki-laki','perempuan') NOT NULL,
  `tanggal_lahir_u` date NOT NULL,
  `email_u` varchar(30) NOT NULL,
  `alamat_u` text NOT NULL,
  `notelp_u` varchar(15) NOT NULL,
  `jabatan_u` enum('ka puskesmas','administrator') NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `username`, `password`, `nama_u`, `jenis_kelamin_u`, `tanggal_lahir_u`, `email_u`, `alamat_u`, `notelp_u`, `jabatan_u`, `tanggal`) VALUES
(23, 'admin', '$2y$10$ZDyAC1ozr8xOWeXM3O5K6u8tJeDQqZR5PNYnGPhpE59KWkywGSzMm', 'Adit Wahyu R', 'laki-laki', '2003-01-05', 'aditwhyrtm03@gmail.com', 'Sondakan,Laweyan', '082233597611', 'administrator', '0000-00-00'),
(27, 'drRamon', '$2y$10$USj2eosFIqHvTgpkDfUlte4HyrnHHUdYAabWeS.Fghc/.e0M1bb6C', 'dr. Ramon Otto A', 'laki-laki', '1990-01-05', 'margahusadasolo@gmail.com', 'Sondakan,Laweyan', '082233597612', '', '0000-00-00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_daftar_pasien`
--
ALTER TABLE `tb_daftar_pasien`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_spesialis` (`id_spesialis`),
  ADD KEY `id_dokter` (`id_dokter`),
  ADD KEY `id_pasien` (`id_pasien`);

--
-- Indexes for table `tb_dokter`
--
ALTER TABLE `tb_dokter`
  ADD PRIMARY KEY (`id_dokter`);

--
-- Indexes for table `tb_pasien`
--
ALTER TABLE `tb_pasien`
  ADD PRIMARY KEY (`id_pasien`);

--
-- Indexes for table `tb_spesialis`
--
ALTER TABLE `tb_spesialis`
  ADD PRIMARY KEY (`id_spesialis`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_daftar_pasien`
--
ALTER TABLE `tb_daftar_pasien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_dokter`
--
ALTER TABLE `tb_dokter`
  MODIFY `id_dokter` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tb_pasien`
--
ALTER TABLE `tb_pasien`
  MODIFY `id_pasien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tb_spesialis`
--
ALTER TABLE `tb_spesialis`
  MODIFY `id_spesialis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_daftar_pasien`
--
ALTER TABLE `tb_daftar_pasien`
  ADD CONSTRAINT `tb_daftar_pasien_ibfk_1` FOREIGN KEY (`id_dokter`) REFERENCES `tb_dokter` (`id_dokter`),
  ADD CONSTRAINT `tb_daftar_pasien_ibfk_2` FOREIGN KEY (`id_pasien`) REFERENCES `tb_pasien` (`id_pasien`),
  ADD CONSTRAINT `tb_daftar_pasien_ibfk_3` FOREIGN KEY (`id_spesialis`) REFERENCES `tb_spesialis` (`id_spesialis`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
