-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 18 Jun 2024 pada 14.26
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbmargahusada`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_daftar_pasien`
--

CREATE TABLE `tb_daftar_pasien` (
  `id` int(11) NOT NULL,
  `id_pasien` int(11) NOT NULL,
  `id_dokter` int(11) DEFAULT NULL,
  `id_spesialis` int(11) NOT NULL,
  `keluhan` text DEFAULT NULL,
  `tanggal_daftar` date NOT NULL,
  `cara_bayar` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_daftar_pasien`
--

INSERT INTO `tb_daftar_pasien` (`id`, `id_pasien`, `id_dokter`, `id_spesialis`, `keluhan`, `tanggal_daftar`, `cara_bayar`) VALUES
(1, 22, 2, 13, 'demam', '2024-06-18', 'umum'),
(2, 23, NULL, 4, NULL, '2024-06-18', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_detail_pasien`
--

CREATE TABLE `tb_detail_pasien` (
  `id_detail_pasien` varchar(11) NOT NULL,
  `id_pasien` int(11) NOT NULL,
  `ket` text NOT NULL,
  `ketentuan_dirawat` enum('ya','tidak') NOT NULL,
  `lama_inap` int(5) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_dokter`
--

CREATE TABLE `tb_dokter` (
  `id_dokter` int(11) NOT NULL,
  `nama_d` varchar(50) NOT NULL,
  `id_spesialis` int(11) NOT NULL,
  `jam_praktek` varchar(20) NOT NULL,
  `jenis_kelamin_d` enum('laki-laki','perempuan') NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_dokter`
--

INSERT INTO `tb_dokter` (`id_dokter`, `nama_d`, `id_spesialis`, `jam_praktek`, `jenis_kelamin_d`, `tanggal`) VALUES
(1, 'dr. Dini Nurul Annisa', 13, '08:00 - 11:00', 'perempuan', '2020-03-01'),
(2, 'dr. Ramon Otto Andinata', 13, '14:00 - 18:00', 'laki-laki', '2020-02-01'),
(3, 'dr. R. Iwan Wahyu U', 13, '18:00 - 20:30', 'laki-laki', '2020-03-02');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_kamar`
--

CREATE TABLE `tb_kamar` (
  `id_kamar` int(11) NOT NULL,
  `no_k` varchar(15) NOT NULL,
  `nama_k` varchar(50) NOT NULL,
  `kelas_k` varchar(20) NOT NULL,
  `status_k` enum('terisi','kosong') NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_kamar`
--

INSERT INTO `tb_kamar` (`id_kamar`, `no_k`, `nama_k`, `kelas_k`, `status_k`, `tanggal`) VALUES
(1, '1', 'Bunga Mawar', '1', 'kosong', '2020-03-01'),
(2, '2', 'Roselia', '1', 'kosong', '2020-03-01'),
(3, '3', 'Garaga', '3', 'terisi', '2020-03-15'),
(4, '4', 'Catiwa', '2', 'kosong', '2020-03-15'),
(5, '55eu', 'Najwa', '2', 'kosong', '2020-04-01'),
(7, '20ef', 'Meria', '3', 'kosong', '2020-04-02'),
(8, '55RF', 'Wirdahun Pole', '1', 'terisi', '2020-04-07');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pasien`
--

CREATE TABLE `tb_pasien` (
  `id_pasien` int(11) NOT NULL,
  `norm` varchar(11) NOT NULL,
  `nik` varchar(16) DEFAULT NULL,
  `nama_p` varchar(50) NOT NULL,
  `umur_p` int(5) NOT NULL,
  `tanggal_lahir_p` date NOT NULL,
  `alamat_p` text NOT NULL,
  `notelp_p` varchar(15) NOT NULL,
  `jenis_kelamin_p` enum('laki-laki','perempuan') NOT NULL,
  `kota_p` text NOT NULL,
  `tanggal` date NOT NULL,
  `terverifikasi` tinyint(1) NOT NULL DEFAULT 1,
  `daftar_online` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_pasien`
--

INSERT INTO `tb_pasien` (`id_pasien`, `norm`, `nik`, `nama_p`, `umur_p`, `tanggal_lahir_p`, `alamat_p`, `notelp_p`, `jenis_kelamin_p`, `kota_p`, `tanggal`, `terverifikasi`, `daftar_online`) VALUES
(22, 'RM000001', '3312160501030002', 'adit', 21, '2003-01-05', 'wonogiri', '', 'laki-laki', '', '0000-00-00', 1, 0),
(23, 'RM000002', '1331214214', 'uji coba', 21, '2024-06-18', 'sasas', '', 'laki-laki', '', '0000-00-00', 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pembayaran`
--

CREATE TABLE `tb_pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_detail_pasien` varchar(11) NOT NULL,
  `jenis_tindakan` enum('rawat inap','periksa') NOT NULL,
  `jumlah_p_tindakan` int(10) NOT NULL,
  `jumlah_p_inap` int(10) NOT NULL,
  `total` int(10) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_rawat`
--

CREATE TABLE `tb_rawat` (
  `id_rawat` int(11) NOT NULL,
  `id_detail_pasien` varchar(11) NOT NULL,
  `id_dokter` int(11) NOT NULL,
  `id_kamar` int(11) NOT NULL,
  `lama_inap` int(5) NOT NULL,
  `tanggal_inap` date NOT NULL,
  `tanggal_selesai_inap` date NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_spesialis`
--

CREATE TABLE `tb_spesialis` (
  `id_spesialis` int(11) NOT NULL,
  `nama_spesialis` varchar(50) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_spesialis`
--

INSERT INTO `tb_spesialis` (`id_spesialis`, `nama_spesialis`, `tanggal`) VALUES
(13, 'Poli Umum', '2024-06-18'),
(14, 'Poli Gigi', '2024-06-18'),
(15, 'Khitan/Sunat', '2024-06-18'),
(16, 'Fisioterapi Pijat Bayi', '2024-06-18'),
(17, 'Vaksin Umroh', '2024-06-18');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `nama_u` varchar(50) NOT NULL,
  `jenis_kelamin_u` enum('laki-laki','perempuan') NOT NULL,
  `tanggal_lahir_u` date NOT NULL,
  `email_u` varchar(30) NOT NULL,
  `alamat_u` text NOT NULL,
  `notelp_u` varchar(15) NOT NULL,
  `jabatan_u` enum('ka puskesmas','administrator') NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `username`, `password`, `nama_u`, `jenis_kelamin_u`, `tanggal_lahir_u`, `email_u`, `alamat_u`, `notelp_u`, `jabatan_u`, `tanggal`) VALUES
(23, 'admin', '$2y$10$ZDyAC1ozr8xOWeXM3O5K6u8tJeDQqZR5PNYnGPhpE59KWkywGSzMm', 'Adit Wahyu R', 'laki-laki', '2003-01-05', 'aditwhyrtm03@gmail.com', 'Sondakan,Laweyan', '082233597611', 'administrator', '0000-00-00'),
(27, 'drRamon', '$2y$10$USj2eosFIqHvTgpkDfUlte4HyrnHHUdYAabWeS.Fghc/.e0M1bb6C', 'dr. Ramon Otto A', 'laki-laki', '1990-01-05', 'margahusadasolo@gmail.com', 'Sondakan,Laweyan', '082233597612', '', '0000-00-00');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_daftar_pasien`
--
ALTER TABLE `tb_daftar_pasien`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_detail_pasien`
--
ALTER TABLE `tb_detail_pasien`
  ADD PRIMARY KEY (`id_detail_pasien`),
  ADD KEY `id_pasien` (`id_pasien`);

--
-- Indeks untuk tabel `tb_dokter`
--
ALTER TABLE `tb_dokter`
  ADD PRIMARY KEY (`id_dokter`);

--
-- Indeks untuk tabel `tb_kamar`
--
ALTER TABLE `tb_kamar`
  ADD PRIMARY KEY (`id_kamar`);

--
-- Indeks untuk tabel `tb_pasien`
--
ALTER TABLE `tb_pasien`
  ADD PRIMARY KEY (`id_pasien`);

--
-- Indeks untuk tabel `tb_pembayaran`
--
ALTER TABLE `tb_pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`),
  ADD KEY `id_detail_pasien` (`id_detail_pasien`);

--
-- Indeks untuk tabel `tb_rawat`
--
ALTER TABLE `tb_rawat`
  ADD PRIMARY KEY (`id_rawat`),
  ADD KEY `id_detail_pasien` (`id_detail_pasien`),
  ADD KEY `id_dokter` (`id_dokter`),
  ADD KEY `id_kamar` (`id_kamar`);

--
-- Indeks untuk tabel `tb_spesialis`
--
ALTER TABLE `tb_spesialis`
  ADD PRIMARY KEY (`id_spesialis`);

--
-- Indeks untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_daftar_pasien`
--
ALTER TABLE `tb_daftar_pasien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tb_dokter`
--
ALTER TABLE `tb_dokter`
  MODIFY `id_dokter` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `tb_kamar`
--
ALTER TABLE `tb_kamar`
  MODIFY `id_kamar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `tb_pasien`
--
ALTER TABLE `tb_pasien`
  MODIFY `id_pasien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT untuk tabel `tb_pembayaran`
--
ALTER TABLE `tb_pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tb_rawat`
--
ALTER TABLE `tb_rawat`
  MODIFY `id_rawat` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tb_spesialis`
--
ALTER TABLE `tb_spesialis`
  MODIFY `id_spesialis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tb_detail_pasien`
--
ALTER TABLE `tb_detail_pasien`
  ADD CONSTRAINT `tb_detail_pasien_ibfk_1` FOREIGN KEY (`id_pasien`) REFERENCES `tb_pasien` (`id_pasien`);

--
-- Ketidakleluasaan untuk tabel `tb_pembayaran`
--
ALTER TABLE `tb_pembayaran`
  ADD CONSTRAINT `tb_pembayaran_ibfk_1` FOREIGN KEY (`id_detail_pasien`) REFERENCES `tb_detail_pasien` (`id_detail_pasien`);

--
-- Ketidakleluasaan untuk tabel `tb_rawat`
--
ALTER TABLE `tb_rawat`
  ADD CONSTRAINT `tb_rawat_ibfk_1` FOREIGN KEY (`id_dokter`) REFERENCES `tb_dokter` (`id_dokter`),
  ADD CONSTRAINT `tb_rawat_ibfk_2` FOREIGN KEY (`id_detail_pasien`) REFERENCES `tb_detail_pasien` (`id_detail_pasien`),
  ADD CONSTRAINT `tb_rawat_ibfk_3` FOREIGN KEY (`id_kamar`) REFERENCES `tb_kamar` (`id_kamar`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
