<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * @property Model_tampil $Model_tampil
 * @property input $input
 * @property form_validation $form_validation
 * @property session $session
 * @property output $output
 * @property db $db
 */
class Daftar extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Model_login');
        $this->load->model('Model_tampil');
        $this->load->helper('main');
        $this->load->library('form_validation');
    }

	public function index()
	{
        $poli = $this->Model_tampil->tampil_spesialis();
        $latestRM = $this->Model_tampil->get_latest_rm() + 1;

        $latestRM = 'RM' . str_pad($latestRM, 6, '0', STR_PAD_LEFT);

		$this->load->view('Daftar/index', [
            'poli' => $poli,
            'latestRM' => $latestRM
        ]);
	}

    public function cari_data_pasien() 
    {
        $norm = $this->input->post('norm');
        $data = $this->Model_tampil->get_single_patient($norm);

        if ($data) {
            return $this->output->set_output(json_encode([
                'status' => 'success',
                'data' => $data
            ]));
        } else {
            return $this->output->set_output(json_encode([
                'status' => 'error',
                'error' => 'Data pasien tidak ditemukan'
            ]));
        }
    }

    public function store()
    {
        $this->form_validation->set_rules('jenis_pasien', 'Jenis Pasien', 'required');
        $this->form_validation->set_rules('norm', 'No RM', 'required');
        $this->form_validation->set_rules('nama_p', 'Nama Pasien', 'required');
        $this->form_validation->set_rules('umur_p', 'Umur Pasien', 'required|numeric');
        $this->form_validation->set_rules('tanggal_lahir_p', 'Tanggal Lahir Pasien', 'required');
        $this->form_validation->set_rules('alamat_p', 'Alamat Pasien', 'required');
        $this->form_validation->set_rules('jenis_kelamin_p', 'Jenis Kelamin Pasien', 'required');
        $this->form_validation->set_rules('nik', 'NIK', 'required|numeric');
        $this->form_validation->set_rules('tanggal', 'Tanggal Periksa', 'required');
        $this->form_validation->set_rules('poli', 'Poli', 'required|numeric');

        if ($this->form_validation->run() === false) {
            $this->session->set_flashdata('error', validation_errors());
            $this->session->set_flashdata('message', 'Data pasien gagal disimpan');
            return redirect('daftar');
        }

        $patient = $this->Model_tampil->get_single_patient($this->input->post('norm'));
        
        if (! $patient) {
            $data = [
                'norm' => $this->input->post('norm'),
                'nama_p' => $this->input->post('nama_p'),
                'umur_p' => $this->input->post('umur_p'),
                'tanggal_lahir_p' => $this->input->post('tanggal_lahir_p'),
                'alamat_p' => $this->input->post('alamat_p'),
                'jenis_kelamin_p' => $this->input->post('jenis_kelamin_p'),
                'nik' => $this->input->post('nik'),
                'terverifikasi' => false,
            ];
            
            $this->db->insert('tb_pasien', $data);

            $patient = $this->Model_tampil->get_single_patient($this->input->post('norm'));
        }
        
        $data = [
            'id_pasien' => $patient->id_pasien,
            'id_spesialis' => $this->input->post('poli'),
            'tanggal_daftar' => $this->input->post('tanggal'),
        ];

        $this->db->insert('tb_daftar_pasien', $data);

        $this->session->set_flashdata('message', '<div class="alert alert-success"> Data pendaftaran pasien berhasil disimpan, silahkan datang ke klinik untuk verifikasi data.</div>');
        return redirect('daftar');
    }
}
