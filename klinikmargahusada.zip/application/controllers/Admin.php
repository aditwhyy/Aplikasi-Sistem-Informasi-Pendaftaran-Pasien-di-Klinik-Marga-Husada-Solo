<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * @property Model_tampil $Model_Tampil
 * @property Model_Update $Model_Update
 * @property Model_Tambah $Model_Tambah
 * @property Model_Hapus $Model_Hapus
 * @property input $input
 * @property form_validation $form_validation
 * @property session $session
 * @property output $output
 * @property db $db
 */
class Admin extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Model_Tampil');
        $this->load->model('Model_Update');
        $this->load->model('Model_Tambah');
        $this->load->model('Model_Hapus');
        $this->load->library('cetak_pdf');
        $this->load->library('PDF_MC_Table');
        $this->load->helper('main');
    }

    public function index()
    {
        $this->load->view('Login/login');
    }

    public function dashboard()
    {
        if ($this->session->userdata('username') == null) {
            redirect('login');
        } else {
            $akses = $this->session->userdata('username');
            $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();
            $data['akses'] = $hak_akses['jabatan_u'];
            $akses = $hak_akses['jabatan_u'];
            $data['nama'] = $hak_akses['nama_u'];
            $data['hitung_pas'] = $this->Model_Tampil->hitung_pas();
            $this->load->view('admin/template/header', $data);
            $this->load->view('admin/template/sidebar', $data);
            $this->load->view('admin/template/navbar', $data);
            $this->load->view('admin/dashboard', $data);
            $this->load->view('admin/template/footer', $data);
        }
    }

    public function pasien()
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();

        $data['akses'] = $hak_akses['jabatan_u'];
        $data['pasien'] =  $this->Model_Tampil->tampil_pasien();
        
        $latestRM = $this->Model_Tampil->get_latest_rm() + 1;
        $data['norm'] = 'RM' . str_pad($latestRM, 6, '0', STR_PAD_LEFT);

        $data['nama'] = $hak_akses['nama_u'];
        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/template/sidebar', $data);
        $this->load->view('admin/template/navbar', $data);
        $this->load->view('admin/pasien', $data);
        $this->load->view('admin/template/footer', $data);
    }

    public function dokter()
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();

        $data['akses'] = $hak_akses['jabatan_u'];
        $data['dokter'] =  $this->Model_Tampil->tampil_dokter();
        $data['nama'] = $hak_akses['nama_u'];
        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/template/sidebar', $data);
        $this->load->view('admin/template/navbar', $data);
        $this->load->view('admin/dokter', $data);
        $this->load->view('admin/template/footer', $data);
    }

    public function spesialis()
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();

        $data['akses'] = $hak_akses['jabatan_u'];
        $data['spesialis'] =  $this->Model_Tampil->tampil_spesialis();
        $data['nama'] = $hak_akses['nama_u'];
        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/template/sidebar', $data);
        $this->load->view('admin/template/navbar', $data);
        $this->load->view('admin/spesialis', $data);
        $this->load->view('admin/template/footer', $data);
    }

    public function user()
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();
        $data['nama'] = $hak_akses['nama_u'];
        $data['akses'] = $hak_akses['jabatan_u'];
        $data['user'] =  $this->Model_Tampil->tampil_user();
        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/template/sidebar', $data);
        $this->load->view('admin/template/navbar', $data);
        $this->load->view('admin/user', $data);
        $this->load->view('admin/template/footer', $data);
    }

    public function pendaftaran()
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();
        $data['nama'] = $hak_akses['nama_u'];
        $data['akses'] = $hak_akses['jabatan_u'];

        $data['pasien'] =  $this->db->select('*')->from('tb_pasien')->where('terverifikasi', true)->get()->result();
        $data['dokter'] =  $this->db->select('*')->from('tb_dokter')->get()->result();
        $data['spesialis'] =  $this->db->select('*')->from('tb_spesialis')->get()->result();

        $data['list'] = $this->Model_Tampil->get_all_registered_patient();

        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/template/sidebar', $data);
        $this->load->view('admin/template/navbar', $data);
        $this->load->view('admin/pendaftaran', $data);
        $this->load->view('admin/template/footer', $data);
    }

    public function about()
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();

        $data['akses'] = $hak_akses['jabatan_u'];
        $data['pasien'] =  $this->Model_Tampil->tampil_pasien();
        $data['nama'] = $hak_akses['nama_u'];
        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/template/sidebar', $data);
        $this->load->view('admin/template/navbar', $data);
        $this->load->view('admin/about', $data);
        $this->load->view('admin/template/footer', $data);
    }

    public function laporan()
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();

        $data['akses'] = $hak_akses['jabatan_u'];
        $data['pasien'] =  $this->Model_Tampil->tampil_pasien();
        $data['nama'] = $hak_akses['nama_u'];
        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/template/sidebar', $data);
        $this->load->view('admin/template/navbar', $data);
        $this->load->view('admin/laporan', $data);
        $this->load->view('admin/template/footer', $data);
    }

    public function lapor_proses()
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();

        $data['akses'] = $hak_akses['jabatan_u'];
        $data['nama'] = $hak_akses['nama_u'];
        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/template/sidebar', $data);
        $this->load->view('admin/template/navbar', $data);
        $this->load->view('admin/laporan', $data);
        $this->load->view('admin/template/footer', $data);
    }

    public function lapor_pasien()
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();
        $data['akses'] = $hak_akses['jabatan_u'];
        $data['nama'] = $hak_akses['nama_u'];
        $data['lapor'] = "Pasien";
        $data['warna'] = "primary";
        if ($this->input->post('periode') == "hari_ini") {
            $data['pasien'] = $this->Model_Tampil->tampil_pasien();
            $this->load->view('admin/laporan/laporan_m_pasien', $data);
        } elseif ($this->input->post('btn_tanggal')) {
            $tanggal1 = $this->input->post('tanggal1');
            $tanggal2 = $this->input->post('tanggal2');
            $query = $this->db->query("SELECT tb_pasien.*, tb_user.nama_u AS nama FROM tb_pasien LEFT JOIN tb_user ON tb_pasien.id_user = tb_user.id_user WHERE tb_pasien.tanggal BETWEEN '" . $tanggal1 . "' and '" . $tanggal2 . "' ")->result_array();
            $data['pasien'] = $query;
            $data['tanggal1'] = $tanggal1;
            $data['tanggal2'] = $tanggal2;
            $this->load->view('admin/laporan/laporan_m_pasien', $data);
        } elseif ($this->input->post('btn_bulan')) {
            $bulan1 = $this->input->post('bulan1');
            $tahun1 = $this->input->post('tahun1');
            $hasil = $tahun1 . "-" . $bulan1;
            $query = $this->db->query("SELECT tb_pasien.*, tb_user.nama_u AS nama FROM tb_pasien LEFT JOIN tb_user ON tb_pasien.id_user = tb_user.id_user WHERE tb_pasien.tanggal LIKE '" . $hasil . "%'")->result_array();
            $data['pasien'] = $query;
            $data['bulan'] = $bulan1;
            $data['tahun'] = $tahun1;
            $this->load->view('admin/laporan/laporan_m_pasien', $data);
        } elseif ($this->input->post('btn_tahun')) {
            $tahun1 = $this->input->post('tahun2');
            $hasil = $tahun1;
            $query = $this->db->query("SELECT tb_pasien.*, tb_user.nama_u AS nama FROM tb_pasien LEFT JOIN tb_user ON tb_pasien.id_user = tb_user.id_user WHERE tb_pasien.tanggal LIKE '%" . $hasil . "%'")->result_array();
            $data['pasien'] = $query;
            $data['tahun'] = $tahun1;
            $this->load->view('admin/laporan/laporan_m_pasien', $data);
        } else {
            if ($this->input->post('periode') == "hari") {
                $data['pilih'] = "Periode-Tanggal";
                $data['periode'] = "hari";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            } elseif ($this->input->post('periode') == "minggu") {
                $data['pilih'] = "Periode- 1 Minggu";
                $data['periode'] = "minggu";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            } elseif ($this->input->post('periode') == "bulan") {
                $data['pilih'] = "Periode-Bulan";
                $data['periode'] = "bulan";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            } elseif ($this->input->post('periode') == "tahun") {
                $data['pilih'] = "Periode-Tahun";
                $data['periode'] = "tahun";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            }
        }
    }

    public function lapor_dokter()
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();
        $data['akses'] = $hak_akses['jabatan_u'];
        $data['nama'] = $hak_akses['nama_u'];
        $data['lapor'] = "Dokter";
        $data['warna'] = "primary";
        if ($this->input->post('periode') == "hari_ini") {
            $data['dokter'] = $this->Model_Tampil->tampil_dokter();
            $this->load->view('admin/laporan/laporan_m_dokter', $data);
        } elseif ($this->input->post('btn_tanggal')) {
            $tanggal1 = $this->input->post('tanggal1');
            $tanggal2 = $this->input->post('tanggal2');
            $query = $this->db->query("SELECT * FROM tb_dokter WHERE tanggal BETWEEN '" . $tanggal1 . "' and '" . $tanggal2 . "' ")->result_array();
            $data['dokter'] = $query;
            $data['tanggal1'] = $tanggal1;
            $data['tanggal2'] = $tanggal2;
            $this->load->view('admin/laporan/laporan_m_dokter', $data);
        } elseif ($this->input->post('btn_bulan')) {
            $bulan1 = $this->input->post('bulan1');
            $tahun1 = $this->input->post('tahun1');
            $hasil = $tahun1 . "-" . $bulan1;
            $query = $this->db->query("SELECT * FROM tb_dokter WHERE tanggal like '%" . $hasil . "%'")->result_array();
            $data['dokter'] = $query;
            $data['bulan'] = $bulan1;
            $data['tahun'] = $tahun1;
            $this->load->view('admin/laporan/laporan_m_dokter', $data);
        } elseif ($this->input->post('btn_tahun')) {
            $tahun1 = $this->input->post('tahun2');
            $hasil = $tahun1;
            $query = $this->db->query("SELECT * FROM tb_dokter WHERE tanggal like '%" . $hasil . "%'")->result_array();
            $data['dokter'] = $query;
            $data['tahun'] = $tahun1;
            $this->load->view('admin/laporan/laporan_m_dokter', $data);
        } else {
            if ($this->input->post('periode') == "hari") {
                $data['pilih'] = "Periode-Tanggal";
                $data['periode'] = "hari";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            } elseif ($this->input->post('periode') == "minggu") {
                $data['pilih'] = "Periode- 1 Minggu";
                $data['periode'] = "minggu";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            } elseif ($this->input->post('periode') == "bulan") {
                $data['pilih'] = "Periode-Bulan";
                $data['periode'] = "bulan";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            } elseif ($this->input->post('periode') == "tahun") {
                $data['pilih'] = "Periode-Tahun";
                $data['periode'] = "tahun";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            }
        }
    }

    public function lapor_user()
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();
        $data['akses'] = $hak_akses['jabatan_u'];
        $data['nama'] = $hak_akses['nama_u'];
        $data['lapor'] = "User";
        $data['warna'] = "primary";
        if ($this->input->post('periode') == "hari_ini") {
            $data['user'] = $this->Model_Tampil->tampil_user();
            $this->load->view('admin/laporan/laporan_m_user', $data);
        } elseif ($this->input->post('btn_tanggal')) {
            $tanggal1 = $this->input->post('tanggal1');
            $tanggal2 = $this->input->post('tanggal2');
            $query = $this->db->query("SELECT * FROM tb_user WHERE tanggal BETWEEN '" . $tanggal1 . "' and '" . $tanggal2 . "' ")->result_array();
            $data['user'] = $query;
            $data['tanggal1'] = $tanggal1;
            $data['tanggal2'] = $tanggal2;
            $this->load->view('admin/laporan/laporan_m_user', $data);
        } elseif ($this->input->post('btn_bulan')) {
            $bulan1 = $this->input->post('bulan1');
            $tahun1 = $this->input->post('tahun1');
            $hasil = $tahun1 . "-" . $bulan1;
            $query = $this->db->query("SELECT * FROM tb_user WHERE tanggal like '%" . $hasil . "%'")->result_array();
            $data['user'] = $query;
            $data['bulan'] = $bulan1;
            $data['tahun'] = $tahun1;
            $this->load->view('admin/laporan/laporan_m_user', $data);
        } elseif ($this->input->post('btn_tahun')) {
            $tahun1 = $this->input->post('tahun2');
            $hasil = $tahun1;
            $query = $this->db->query("SELECT * FROM tb_user WHERE tanggal like '%" . $hasil . "%'")->result_array();
            $data['user'] = $query;
            $data['tahun'] = $tahun1;
            $this->load->view('admin/laporan/laporan_m_user', $data);
        } else {
            if ($this->input->post('periode') == "hari") {
                $data['pilih'] = "Periode-Tanggal";
                $data['periode'] = "hari";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            } elseif ($this->input->post('periode') == "minggu") {
                $data['pilih'] = "Periode- 1 Minggu";
                $data['periode'] = "minggu";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            } elseif ($this->input->post('periode') == "bulan") {
                $data['pilih'] = "Periode-Bulan";
                $data['periode'] = "bulan";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            } elseif ($this->input->post('periode') == "tahun") {
                $data['pilih'] = "Periode-Tahun";
                $data['periode'] = "tahun";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            }
        }
    }

    public function lapor_spesialis()
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();
        $data['akses'] = $hak_akses['jabatan_u'];
        $data['nama'] = $hak_akses['nama_u'];
        $data['lapor'] = "Spesialis";
        $data['warna'] = "success";
        if ($this->input->post('periode') == "hari_ini") {
            $data['spesialis'] = $this->Model_Tampil->tampil_spesialis();
            $this->load->view('admin/laporan/laporan_m_spesialis', $data);
        } elseif ($this->input->post('btn_tanggal')) {
            $tanggal1 = $this->input->post('tanggal1');
            $tanggal2 = $this->input->post('tanggal2');
            $query = $this->db->query("SELECT * FROM tb_spesialis WHERE tanggal BETWEEN '" . $tanggal1 . "' and '" . $tanggal2 . "' ")->result_array();
            $data['spesialis'] = $query;
            $data['tanggal1'] = $tanggal1;
            $data['tanggal2'] = $tanggal2;
            $this->load->view('admin/laporan/laporan_m_spesialis', $data);
        } elseif ($this->input->post('btn_bulan')) {
            $bulan1 = $this->input->post('bulan1');
            $tahun1 = $this->input->post('tahun1');
            $hasil = $tahun1 . "-" . $bulan1;
            $query = $this->db->query("SELECT * FROM tb_spesialis WHERE tanggal like '%" . $hasil . "%'")->result_array();
            $data['spesialis'] = $query;
            $data['bulan'] = $bulan1;
            $data['tahun'] = $tahun1;
            $this->load->view('admin/laporan/laporan_m_spesialis', $data);
        } elseif ($this->input->post('btn_tahun')) {
            $tahun1 = $this->input->post('tahun2');
            $hasil = $tahun1;
            $query = $this->db->query("SELECT * FROM tb_spesialis WHERE tanggal like '%" . $hasil . "%'")->result_array();
            $data['spesialis'] = $query;
            $data['tahun'] = $tahun1;
            $this->load->view('admin/laporan/laporan_m_spesialis', $data);
        } else {
            if ($this->input->post('periode') == "hari") {
                $data['pilih'] = "Periode-Tanggal";
                $data['periode'] = "hari";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            } elseif ($this->input->post('periode') == "minggu") {
                $data['pilih'] = "Periode- 1 Minggu";
                $data['periode'] = "minggu";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            } elseif ($this->input->post('periode') == "bulan") {
                $data['pilih'] = "Periode-Bulan";
                $data['periode'] = "bulan";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            } elseif ($this->input->post('periode') == "tahun") {
                $data['pilih'] = "Periode-Tahun";
                $data['periode'] = "tahun";
                $this->load->view('admin/template/header', $data);
                $this->load->view('admin/template/sidebar', $data);
                $this->load->view('admin/template/navbar', $data);
                $this->load->view('admin/laporan_proses', $data);
                $this->load->view('admin/template/footer', $data);
            }
        }
    }

    public function lapor_pendaftaran()
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();
        $data['akses'] = $hak_akses['jabatan_u'];
        $data['nama'] = $hak_akses['nama_u'];
        $data['lapor'] = "Pendaftaran Pasien";
        $data['warna'] = "danger";


        if ($this->input->post('periode') == "hari_ini") {
            $data['pasien'] = $this->Model_Tampil->get_all_registered_patient(true);
            $this->load->view('admin/laporan/laporan_t_pendaftaran', $data);
        } elseif ($this->input->post('btn_tanggal')) {
            $tanggal1 = $this->input->post('tanggal1');
            $tanggal2 = $this->input->post('tanggal2');
            $data['pasien'] = $this->db->select('tb_daftar_pasien.id as id_daftar, norm, nama_p, nama_d, nama_spesialis, keluhan, tanggal_daftar, cara_bayar, tb_user.nama_u as petugas')
                ->from('tb_daftar_pasien')
                ->join('tb_pasien', 'tb_pasien.id_pasien = tb_daftar_pasien.id_pasien')
                ->join('tb_dokter', 'tb_dokter.id_dokter = tb_daftar_pasien.id_dokter')
                ->join('tb_spesialis', 'tb_spesialis.id_spesialis = tb_daftar_pasien.id_spesialis')
                ->join('tb_user', 'tb_user.id_user = tb_pasien.id_user', 'left')
                ->where('tanggal_daftar >=', $tanggal1)
                ->where('tanggal_daftar <=', $tanggal2)
                ->get()
                ->result();
            $data['tanggal1'] = $tanggal1;
            $data['tanggal2'] = $tanggal2;
            $this->load->view('admin/laporan/laporan_t_pendaftaran', $data);
        } elseif ($this->input->post('btn_bulan')) {
            $bulan1 = $this->input->post('bulan1');
            $tahun1 = $this->input->post('tahun1');
            $hasil = $tahun1 . "-" . $bulan1;
            $data['pasien'] = $this->db->select('tb_daftar_pasien.id as id_daftar, norm, nama_p, nama_d, nama_spesialis, keluhan, tanggal_daftar, cara_bayar, tb_user.nama_u as petugas')
                ->from('tb_daftar_pasien')
                ->join('tb_pasien', 'tb_pasien.id_pasien = tb_daftar_pasien.id_pasien')
                ->join('tb_dokter', 'tb_dokter.id_dokter = tb_daftar_pasien.id_dokter')
                ->join('tb_spesialis', 'tb_spesialis.id_spesialis = tb_daftar_pasien.id_spesialis')
                ->join('tb_user', 'tb_user.id_user = tb_pasien.id_user', 'left')
                ->like('tanggal_daftar', $hasil)
                ->get()
                ->result();
            $data['bulan'] = $bulan1;
            $data['tahun'] = $tahun1;
            $this->load->view('admin/laporan/laporan_t_pendaftaran', $data);
        } elseif ($this->input->post('btn_tahun')) {
            $tahun1 = $this->input->post('tahun2');
            $hasil = $tahun1;
            $data['pasien'] = $this->db->select('tb_daftar_pasien.id as id_daftar, norm, nama_p, nama_d, nama_spesialis, keluhan, tanggal_daftar, cara_bayar, tb_user.nama_u as petugas')
                ->from('tb_daftar_pasien')
                ->join('tb_pasien', 'tb_pasien.id_pasien = tb_daftar_pasien.id_pasien')
                ->join('tb_dokter', 'tb_dokter.id_dokter = tb_daftar_pasien.id_dokter')
                ->join('tb_spesialis', 'tb_spesialis.id_spesialis = tb_daftar_pasien.id_spesialis')
                ->join('tb_user', 'tb_user.id_user = tb_pasien.id_user', 'left')
                ->like('tanggal_daftar', $hasil)
                ->get()
                ->result();
            $data['tahun'] = $tahun1;
            $this->load->view('admin/laporan/laporan_t_pendaftaran', $data);
        } else {
            if ($this->input->post('periode') == "hari") {
                $data['pilih'] = "Periode-Tanggal";
                $data['periode'] = "hari";
            } elseif ($this->input->post('periode') == "minggu") {
                $data['pilih'] = "Periode- 1 Minggu";
                $data['periode'] = "minggu";
            } elseif ($this->input->post('periode') == "bulan") {
                $data['pilih'] = "Periode-Bulan";
                $data['periode'] = "bulan";
            } elseif ($this->input->post('periode') == "tahun") {
                $data['pilih'] = "Periode-Tahun";
                $data['periode'] = "tahun";
            }

            $this->load->view('admin/template/header', $data);
            $this->load->view('admin/template/sidebar', $data);
            $this->load->view('admin/template/navbar', $data);
            $this->load->view('admin/laporan_proses', $data);
            $this->load->view('admin/template/footer', $data);
        }
    }

    public function edit_profile()
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();
        $data['akses'] = $hak_akses['jabatan_u'];
        $data['id'] = $hak_akses['id_user'];
        $data['nama'] = $hak_akses['nama_u'];
        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/template/sidebar', $data);
        $this->load->view('admin/template/navbar', $data);
        $this->load->view('admin/edit_profile', $data);
        $this->load->view('admin/template/footer', $data);
    }

    public function edit_pasien($id)
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();
        $data['id'] = $id;
        $data['akses'] = $hak_akses['jabatan_u'];
        $data['nama'] = $hak_akses['nama_u'];
        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/template/sidebar', $data);
        $this->load->view('admin/template/navbar', $data);
        $this->load->view('admin/e_pasien', $data);
        $this->load->view('admin/template/footer', $data);
    }

    public function edit_dokter($id)
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();
        $data['nama'] = $hak_akses['nama_u'];
        $data['id'] = $id;
        $data['akses'] = $hak_akses['jabatan_u'];
        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/template/sidebar', $data);
        $this->load->view('admin/template/navbar', $data);
        $this->load->view('admin/e_dokter', $data);
        $this->load->view('admin/template/footer', $data);
    }

    public function edit_spesialis($id)
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();
        $data['nama'] = $hak_akses['nama_u'];
        $data['id'] = $id;
        $data['akses'] = $hak_akses['jabatan_u'];
        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/template/sidebar', $data);
        $this->load->view('admin/template/navbar', $data);
        $this->load->view('admin/e_spesialis', $data);
        $this->load->view('admin/template/footer', $data);
    }

    public function edit_user($id)
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();
        $data['id'] = $id;
        $data['akses'] = $hak_akses['jabatan_u'];
        $data['nama'] = $hak_akses['nama_u'];
        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/template/sidebar', $data);
        $this->load->view('admin/template/navbar', $data);
        $this->load->view('admin/e_user', $data);
        $this->load->view('admin/template/footer', $data);
    }

    public function edit_pendaftaran($id)
    {
        $akses = $this->session->userdata('username');
        $hak_akses = $this->db->get_where('tb_user', ['username' => $akses])->row_array();
        $data['id'] = $id;
        $data['akses'] = $hak_akses['jabatan_u'];
        $data['nama'] = $hak_akses['nama_u'];

        $data['id'] = $id;
        $data['pendaftaran'] = $this->db->get_where('tb_daftar_pasien', ['id' => $id])->row();

        $data['pasien'] = $this->db->get_where('tb_pasien', ['id_pasien' => $data['pendaftaran']->id_pasien])->row();
        $data['dokter'] =  $this->db->select('*')->from('tb_dokter')->get()->result();
        $data['spesialis'] =  $this->db->select('*')->from('tb_spesialis')->get()->result();

        $this->load->view('admin/template/header', $data);
        $this->load->view('admin/template/sidebar', $data);
        $this->load->view('admin/template/navbar', $data);
        $this->load->view('admin/e_pendaftaran', $data);
        $this->load->view('admin/template/footer', $data);
    }

    public function acakkode()
    {
        $quer = $this->db->query("SELECT RIGHT(norm, 3) as pasien FROM `tb_pasien` ORDER BY norm DESC")->row_array();
        $akhir = intval($quer['pasien']);
        $i = 1;
        $akhir = $akhir + 1;
        if (strlen($akhir) == 1) {
            $a = "RM00000" . $akhir;
        } elseif (strlen($akhir) == 2) {
            $a = "RM0000" . $akhir;
        } elseif (strlen($akhir) == 3) {
            $a = "RM" . $akhir;
        } else {
            $a = "RM000001";
        }
        return $a;
    }

    public function input_pasien()
    {
        $this->form_validation->set_rules('norm', 'norm', 'required|trim');
        $this->form_validation->set_rules('nama_p', 'Nama Pasien', 'required|trim');
        // $this->form_validation->set_rules('umur_p', 'Umur Pasien', 'required|trim');
        $this->form_validation->set_rules('tanggal_lahir_p', 'Tanggal Lahir Pasien', 'required|trim');
        $this->form_validation->set_rules('notelp_p', 'No Telepon Pasien', 'required|trim');
        $this->form_validation->set_rules('alamat_p', 'Alamat Pasien', 'required|trim');
        $this->form_validation->set_rules('jenis_kelamin_p', 'Gender Pasien', 'required|trim');
        $this->form_validation->set_rules('nik', 'NIK Pasien', 'required|trim');
        $this->form_validation->set_rules('kota_p', 'Kota Pasien', 'required|trim');

        if ($this->form_validation->run() === false) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger col-md-12 text-center" role="alert">Isi data dengan lengkap</div>');
            redirect('admin/pasien');
        } else {
            $akses = $this->session->userdata('username');
            $this->Model_Tambah->insert_pasien();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Pasien Sudah di Ditambahkan</div>');
            redirect('admin/pasien');
        }
    }

    public function input_daftar()
    {
        $this->form_validation->set_rules('id_pasien', 'Pasien', 'required|trim');
        $this->form_validation->set_rules('id_dokter', 'Dokter', 'required|trim');
        $this->form_validation->set_rules('id_spesialis', 'Pasien', 'required|trim');
        $this->form_validation->set_rules('keluhan', 'Keluhan Pasien', 'required|trim');
        $this->form_validation->set_rules('tanggal_daftar', 'Tanggal Daftar', 'required|trim');
        $this->form_validation->set_rules('cara_bayar', 'Cara Bayar', 'required|trim');

        if ($this->form_validation->run() === false) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger col-md-12 text-center" role="alert">Isi data dengan lengkap</div>');
            redirect('admin/pendaftaran');
        } else {
            $this->Model_Tambah->insert_pendaftaran();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Pendaftaran Sudah di Ditambahkan</div>');
            redirect('admin/pendaftaran');
        }
    }

    public function input_user()
    {
        $this->form_validation->set_rules('nama_u', 'Nama Lengkap', 'required|trim');
        $this->form_validation->set_rules('username', 'username', 'required|trim');
        $this->form_validation->set_rules('password', 'password', 'required|trim');
        $this->form_validation->set_rules('jenis_kelamin_u', 'Jenis Kelamin User', 'required|trim');
        $this->form_validation->set_rules('tanggal_lahir_u', 'Tanggal Lahir User', 'required|trim');
        $this->form_validation->set_rules('notelp_u', 'No Telepon', 'required|trim');
        $this->form_validation->set_rules('email_u', 'Email', 'required|trim');
        $this->form_validation->set_rules('jabatan_u', 'Jabatan U', 'required|trim');
        $this->form_validation->set_rules('alamat_u', 'Alamat User', 'required|trim');

        if ($this->form_validation->run() === false) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger col-md-12 text-center" role="alert">Isi data dengan lengkap</div>');
            redirect('admin/user');
        } else {
            $this->Model_Tambah->insert_user();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data User Sudah di Ditambahkan</div>');
            redirect('admin/user');
        }
    }

    public function input_dokter()
    {

        $this->form_validation->set_rules('nama_d', 'Nama Dokter', 'required|trim');
        $this->form_validation->set_rules('spesialis', 'Spesialis', 'required|trim');
        $this->form_validation->set_rules('jam_praktek', 'Jam Praktik', 'required|trim');
        $this->form_validation->set_rules('jenis_kelamin_d', 'Gender Dokter', 'required|trim');

        if ($this->form_validation->run() === false) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger col-md-12 text-center" role="alert">Isi data dengan lengkap</div>');
            redirect('admin/dokter');
        } else {
            $this->Model_Tambah->insert_dokter();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Dokter Sudah di Ditambahkan</div>');
            redirect('admin/dokter');
        }
    }

    public function input_spesialis()
    {
        $this->form_validation->set_rules('nama_s', 'Nama Spesialis', 'required|trim');

        if ($this->form_validation->run() === false) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger col-md-12 text-center" role="alert">Isi data dengan lengkap</div>');
            redirect('admin/spesialis');
        } else {
            $this->Model_Tambah->insert_spesialis();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Spesialis Sudah di Ditambahkan</div>');
            redirect('admin/spesialis');
        }
    }

    public function hapus_pasien($id)
    {
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Pasien Sudah di Hapus</div>');
        $this->Model_Hapus->hapus_pasien($id);
        redirect('admin/pasien');
    }

    public function hapus_dokter($id)
    {
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Dokter Sudah di Hapus</div>');
        $this->Model_Hapus->hapus_dokter($id);
        redirect('admin/dokter');
    }

    public function hapus_spesialis($id)
    {
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Spesialis Sudah di Hapus</div>');
        $this->Model_Hapus->hapus_spesialis($id);
        redirect('admin/spesialis');
    }

    public function hapus_user($id)
    {
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data User Sudah di Hapus</div>');
        $this->Model_Hapus->hapus_user($id);
        redirect('admin/user');
    }

    public function hapus_pendaftaran($id)
    {
        try {
            $this->Model_Hapus->hapus_pendaftaran($id);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Pendaftaran Sudah di Hapus</div>');
            redirect('admin/pendaftaran');
        } catch (\Throwable $th) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Data Pendaftaran Gagal di Hapus</div>');
            redirect('admin/pendaftaran');
        }
    }

    public function update_pasien()
    {
        $this->form_validation->set_rules('nama_p', 'Nama Pasien', 'required|trim');
        // $this->form_validation->set_rules('umur_p', 'Umur Pasien', 'required|trim');
        $this->form_validation->set_rules('tanggal_lahir_p', 'Tanggal Lahir Pasien', 'required|trim');
        $this->form_validation->set_rules('notelp_p', 'No Telepon Pasien', 'required|trim');
        $this->form_validation->set_rules('alamat_p', 'Alamat Pasien', 'required|trim');
        $this->form_validation->set_rules('jenis_kelamin_p', 'Gender Pasien', 'required|trim');
        $this->form_validation->set_rules('kota_p', 'Kota Pasien', 'required|trim');
        if ($this->form_validation->run() === false) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger col-md-12 text-center" role="alert">Isi data dengan lengkap</div>');
            redirect('admin/edit_pasien/' . $this->input->post('id_p'));
        } else {
            $this->Model_Update->update_pasien();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Pasien Sudah di Diubah</div>');
            redirect('admin/pasien');
        }
    }

    public function update_user()
    {
        $this->form_validation->set_rules('nama_u', 'Nama Lengkap', 'required|trim');
        $this->form_validation->set_rules('username', 'username', 'required|trim');
        $this->form_validation->set_rules('jenis_kelamin_u', 'Jenis Kelamin User', 'required|trim');
        $this->form_validation->set_rules('tanggal_lahir_u', 'Tanggal Lahir User', 'required|trim');
        $this->form_validation->set_rules('notelp_u', 'No Telepon', 'required|trim');
        $this->form_validation->set_rules('email_u', 'Email', 'required|trim');
        $this->form_validation->set_rules('alamat_u', 'Alamat User', 'required|trim');
        if ($this->form_validation->run() === false) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger col-md-12 text-center" role="alert">Isi data dengan lengkap</div>');
            redirect('admin/edit_user/' . $this->input->post('id_u'));
        } else {
            $this->Model_Update->update_user();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data User Sudah di Diubah</div>');
            redirect('admin/dashboard');
        }
    }

    public function update_dokter()
    {
        $this->form_validation->set_rules('nama_d', 'Nama Dokter', 'required|trim');
        $this->form_validation->set_rules('id_spesialis', 'Spesialis', 'required|trim');
        $this->form_validation->set_rules('jam_praktek', 'Jam Praktik', 'required|trim');
        $this->form_validation->set_rules('jenis_kelamin_d', 'Gender Dokter', 'required|trim');
        if ($this->form_validation->run() === false) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger col-md-12 text-center" role="alert">Isi data dengan lengkap</div>');
            redirect('admin/edit_dokter/' . $this->input->post('id_d'));
        } else {
            $this->Model_Update->update_dokter();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Dokter Sudah di Diubah</div>');
            redirect('admin/dokter');
        }
    }

    public function update_spesialis()
    {
        $this->form_validation->set_rules('nama_s', 'Nama Spesialis', 'required|trim');
        if ($this->form_validation->run() === false) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger col-md-12 text-center" role="alert">Isi data dengan lengkap</div>');
            redirect('admin/edit_spesialis/' . $this->input->post('id_s'));
        } else {
            $this->Model_Update->update_spesialis();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Spesialis Sudah di Diubah</div>');
            redirect('admin/spesialis');
        }
    }

    public function update_pendaftaran($id)
    {
        $this->form_validation->set_rules('id_dokter', 'Dokter', 'required', ['required' => 'Dokter harus diisi.']);
        $this->form_validation->set_rules('id_spesialis', 'Poli', 'required', ['required' => 'Poli harus diisi.']);
        $this->form_validation->set_rules('keluhan', 'Keluhan Pasien', 'required', ['required' => 'Keluhan pasien harus diisi.']);
        $this->form_validation->set_rules('tanggal_daftar', 'Tanggal Daftar', 'required', ['required' => 'Tanggal daftar harus diisi.']);
        $this->form_validation->set_rules('cara_bayar', 'Cara Bayar', 'required', ['required' => 'Cara bayar harus diisi.']);

        if ($this->form_validation->run() === false) {
            $this->session->set_flashdata('error', validation_errors());
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Data pendaftaran pasien gagal disimpan.<br><small>' . validation_errors() . '</small></div>');
            return redirect('admin/edit_pendaftaran/' . $id);
        }

        $data = [
            'id_dokter' => $this->input->post('id_dokter'),
            'id_spesialis' => $this->input->post('id_spesialis'),
            'keluhan' => $this->input->post('keluhan'),
            'tanggal_daftar' => $this->input->post('tanggal_daftar'),
            'cara_bayar' => $this->input->post('cara_bayar'),
        ];

        try {
            $this->db->where('id', $id)->update('tb_daftar_pasien', $data);

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data pendaftaran pasien berhasil diperbarui.</div>');
            return redirect('admin/pendaftaran');
        } catch (\Throwable $th) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Data pendaftaran pasien gagal diperbarui.<br><small>' . $th->getMessage() . '</small></div>');
            return redirect('admin/edit/pendaftaran/' . $id);
        }
    }

    public function verifikasi_pasien($id)
    {
        $this->Model_Update->verifikasi_pasien($id);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Pasien Sudah di Verifikasi</div>');
        redirect('admin/pasien');
    }

    public function cetak_kib($id)
    {
        $data['pasien'] = $this->db->select('*')->from('tb_pasien')->where('id_pasien', $id)->get()->row();

        $this->load->view('admin/laporan/cetak_kib', $data);
    }
}
