<?php
class Model_Tambah extends CI_Model
{

    public function insert_pasien()
    {
        $tanggal = date('Y-m-d');
        $officer = isset($this->session->userdata['id_user']) ? $this->session->userdata['id_user'] : null;
        $data = [
            'norm' => htmlspecialchars($this->input->post('norm', true)),
            'nama_p' => htmlspecialchars($this->input->post('nama_p', true)),
            // 'umur_p' => htmlspecialchars($this->input->post('umur_p', true)),
            'tanggal_lahir_p' => htmlspecialchars($this->input->post('tanggal_lahir_p', true)),
            'notelp_p' => htmlspecialchars($this->input->post('notelp_p', true)),
            'alamat_p' => htmlspecialchars($this->input->post('alamat_p', true)),
            'jenis_kelamin_p' => htmlspecialchars($this->input->post('jenis_kelamin_p', true)),
            'nik' => htmlspecialchars($this->input->post('nik', true)),
            'kota_p' => htmlspecialchars($this->input->post('kota_p', true)),
            'tanggal' => $tanggal,
            'id_user' => $officer,
        ];
        $this->db->insert('tb_pasien', $data);
    }

    public function insert_pendaftaran()
    {
        $tanggal = date('Y-m-d');
        $data = [
            'id_pasien' => htmlspecialchars($this->input->post('id_pasien', true)),
            'id_dokter' => htmlspecialchars($this->input->post('id_dokter', true)),
            'id_spesialis' => htmlspecialchars($this->input->post('id_spesialis', true)),
            'tanggal_daftar' => $tanggal,
            'keluhan' => htmlspecialchars($this->input->post('keluhan', true)),
            'cara_bayar' => htmlspecialchars($this->input->post('caa_bayar', true)),
        ];
        $this->db->insert('tb_daftar_pasien', $data);
    }

    public function insert_dokter()
    {
        $data = [
            'nama_d' => htmlspecialchars($this->input->post('nama_d', true)),
            'id_spesialis' => htmlspecialchars($this->input->post('spesialis', true)),
            'jam_praktek' => htmlspecialchars($this->input->post('jam_praktek', true)),
            'jenis_kelamin_d' => htmlspecialchars($this->input->post('jenis_kelamin_d', true))
        ];
        $this->db->insert('tb_dokter', $data);
    }

    public function insert_spesialis()
    {
        $tanggal = date('Y-m-d');
        $data = [
            'nama_spesialis' => htmlspecialchars($this->input->post('nama_s', true)),
            'tanggal' => $tanggal
        ];
        $this->db->insert('tb_spesialis', $data);
    }

    public function insert_user()
    {
        $tanggal = date('Y-m-d');
        $data = [
            'username' => htmlspecialchars($this->input->post('username', true)),
            'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
            'nama_u' => htmlspecialchars($this->input->post('nama_u', true)),
            'jenis_kelamin_u' => htmlspecialchars($this->input->post('jenis_kelamin_u', true)),
            'tanggal_lahir_u' => htmlspecialchars($this->input->post('tanggal_lahir_u', true)),
            'email_u' => htmlspecialchars($this->input->post('email_u', true)),
            'alamat_u' => htmlspecialchars($this->input->post('alamat_u', true)),
            'notelp_u' => htmlspecialchars($this->input->post('notelp_u', true)),
            'jabatan_u' => htmlspecialchars($this->input->post('jabatan_u', true)),
            'tanggal' => $tanggal
        ];
        $this->db->insert('tb_user', $data);
    }

}
