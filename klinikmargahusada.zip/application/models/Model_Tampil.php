<?php
class Model_Tampil extends CI_Model
{

    public function tampil_pasien()
    {
        // return $this->db->get('tb_pasien')->result_array();
        return $this->db->select('tb_pasien.*, tb_user.nama_u as nama')
                        ->from('tb_pasien')
                        ->join('tb_user', 'tb_pasien.id_user = tb_user.id_user', 'left')
                        ->get()
                        ->result_array();
    }

    public function tampil_dokter()
    {
        return $this->db->get('tb_dokter')->result_array();
    }

    public function tampil_spesialis()
    {
        return $this->db->get('tb_spesialis')->result_array();
    }

    public function tampil_user()
    {
        return $this->db->get('tb_user')->result_array();
    }

    public function tampil_pendaftaran()
    {
        return $this->db->get('tb_daftar_pasien')->result_array();
    }

    public function hitung_pas()
    {
        $query = "SELECT count(id_pasien) as pasien_j FROM tb_pasien";
        return $this->db->query($query)->row()->pasien_j;
    }

    public function get_latest_rm()
    {
        $last = $this->db->select('norm')->order_by('id_pasien', 'DESC')->limit(1)->get('tb_pasien')->row('norm');
        return substr($last, 2);
    }


    public function get_single_patient($norm)
    {
        return $this->db->get_where('tb_pasien', ['norm' => $norm])->row();
    }

    public function get_all_registered_patient($withoutVerified = false)
    {
        return $this->db->select('tb_daftar_pasien.id as id_daftar, norm, nama_p, nama_d, nama_spesialis, keluhan, tanggal_daftar, cara_bayar, tb_user.nama_u as petugas')
            ->from('tb_daftar_pasien')
            ->join('tb_pasien', 'tb_pasien.id_pasien = tb_daftar_pasien.id_pasien')
            ->join('tb_dokter', 'tb_dokter.id_dokter = tb_daftar_pasien.id_dokter', ($withoutVerified ? 'inner' : 'left'))
            ->join('tb_spesialis', 'tb_spesialis.id_spesialis = tb_daftar_pasien.id_spesialis', ($withoutVerified ? 'inner' : 'left'))
            ->join('tb_user', 'tb_user.id_user = tb_pasien.id_user', ($withoutVerified ? 'inner' : 'left'))
            ->get()
            ->result();
    }
}
