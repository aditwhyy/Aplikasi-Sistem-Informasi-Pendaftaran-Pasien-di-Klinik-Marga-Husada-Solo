<?php

function dd($var){
  echo "<pre>";
  print_r($var);
  echo "</pre>";
  die;
}

function convertToIndonesianDate($inputDate) {
  // Split the input date into year, month, and day
  list($year, $month, $day) = explode('-', $inputDate);

  // Define an array of Indonesian month names
  $indonesianMonths = [
      1 => 'Januari',
      2 => 'Februari',
      3 => 'Maret',
      4 => 'April',
      5 => 'Mei',
      6 => 'Juni',
      7 => 'Juli',
      8 => 'Agustus',
      9 => 'September',
      10 => 'Oktober',
      11 => 'November',
      12 => 'Desember',
  ];

  // Get the month name in Indonesian
  $indonesianMonth = $indonesianMonths[(int)$month];

  // Format the date as "dd MonthName yyyy"
  $formattedDate = $day . ' ' . $indonesianMonth . ' ' . $year;

  return $formattedDate;
}

function indonesianMonths($month) {
  $indonesianMonths = [
    1 => 'Januari',
    2 => 'Februari',
    3 => 'Maret',
    4 => 'April',
    5 => 'Mei',
    6 => 'Juni',
    7 => 'Juli',
    8 => 'Agustus',
    9 => 'September',
    10 => 'Oktober',
    11 => 'November',
    12 => 'Desember',
  ];

  return $indonesianMonths[(int)$month];
}