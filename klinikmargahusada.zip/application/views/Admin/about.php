<div class="container-fluid">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="alert bg-success" role="alert">
          <h4 class="text-center text-light">About Us </h4>
        </div>
        <div class="card-body">
          <div class="card">
            <div class="row no-gutters">
              <div class="col-md-6">
                <img src="<?= base_url('assets/img/LogoMG.jpg'); ?>" class="card-img" alt="...">
              </div>
              <div class="col-md-6">
                <div class="card-body">
                  <h5 class="card-title">Aplikasi</h5>
                  <p class="card-text"></p>
                  <p class="card-text"><small class="text-muted"></small></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>