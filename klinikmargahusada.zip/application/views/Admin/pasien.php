<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <?= $this->session->flashdata('message'); ?>
    <div class="row">
        <div class="col-md-3">
            <div class="card">
                <div class="alert bg-success" role="alert">
                    <h4 class="text-center text-light">Form Pasien</h4>
                </div>
                <div class="card-body">
                    <form method="post" action="<?= base_url('admin/input_pasien'); ?>">
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="inputEmail4">No.RM</label>
                                <div class="input-group mb-2">
                                    <input type="text" class="form-control" id="norm" name="norm" placeholder="No RM" style="background-color: bisque;" value="<?= $norm ?>" placeholder="" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="inputEmail4">Nama Pasien</label>
                                <input type="text" name="nama_p" class="form-control" id="inputEmail4" placeholder="" autocomplete="off">
                            </div>
                        </div>
                        <!-- <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="inputPassword4">Umur Pasien</label>
                                <input type="number" name="umur_p" class="form-control" placeholder="... Tahun">
                            </div>
                        </div> -->
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="inputAddress">Tanggal Lahir Pasien</label>
                                <div class="date">
                                    <input type="date" class="form-control" id="tanggal_lahir_p" name="tanggal_lahir_p" aria-describedby="emailHelp" placeholder="">
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="inputAddress2">No Telp Pasien</label>
                                <input type="number" name="notelp_p" class="form-control" id="inputAddress2" placeholder="" autocomplete="off">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="inputAddress2">Alamat Pasien</label>
                                <textarea class="form-control" name="alamat_p" id="alamat_p" rows="2" placeholder="" autocomplete="off"></textarea>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="inputAddress2">Jenis Kelamin</label>
                                <select class="form-control" name="jenis_kelamin_p">
                                    <option>Pilih Jenis Kelamin ...</option>
                                    <option value="laki-laki">Laki-Laki</option>
                                    <option value="perempuan">Perempuan</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="inputAddress2">NIK</label>
                                <input type="number" name="nik" class="form-control" id="inputNIK" placeholder="NIK" autocomplete="off">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="inputAddress2">Kota</label>
                                <input type="text" name="kota_p" class="form-control" id="inputAddress2" placeholder="" autocomplete="off">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success">Simpan Data</button>
                    </form>
                </div>

                <!-- Modal Hapus  -->
                <div class="modal fade" id="hapusModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
                                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body">Apakah data ingin dihapus ?</div>
                            <div class="modal-footer">
                                <button class="btn btn-secondary" type="button" data-dismiss="modal">No</button>
                                <a class="btn btn-danger" id="btn-yes" href="">Yes</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="alert bg-success" role="alert">
                    <h4 class="text-center text-light">Table Pasien</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%">
                            <thead>
                                <tr>
                                    <th style="background-color: yellow;">No</th>
                                    <th style="background-color: yellow;">No. RM</th>
                                    <th style="background-color: yellow;">Nama</th>
                                    <!-- <th style="background-color: yellow;">Umur</th> -->
                                    <th style="background-color: yellow;">Tanggal Lahir</th>
                                    <th style="background-color: yellow;">Alamat </th>
                                    <th style="background-color: yellow;">No Telp </th>
                                    <th style="background-color: yellow;">Gender </th>
                                    <th style="background-color: yellow;">NIK</th>
                                    <th style="background-color: yellow;">Kota</th>
                                    <th style="background-color: yellow;">Aksi</th>
                                    <th style="background-color: yellow;">Petugas</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php foreach ($pasien as $tpasien) : ?>
                                    <tr class="alert-success">
                                        <td><?= $no++; ?></td>
                                        <td><?= $tpasien['norm']; ?></td>
                                        <td><?= $tpasien['nama_p']; ?></td>
                                        <!-- <td><?= $tpasien['umur_p']; ?></td> -->
                                        <td><?= $tpasien['tanggal_lahir_p']; ?></td>
                                        <td><?= $tpasien['alamat_p']; ?></td>
                                        <td><?= $tpasien['notelp_p']; ?></td>
                                        <td><?= $tpasien['jenis_kelamin_p']; ?></td>
                                        <td><?= $tpasien['nik']; ?></td>
                                        <td><?= $tpasien['kota_p']; ?></td>
                                        <td>
                                            <a href="<?= base_url('admin/edit_pasien/') . $tpasien['id_pasien']; ?>"><span class="badge badge-pill badge-primary">Edit</span></a> |
                                            <!--<a href="" class="hapusModalpasien" data-target="#hapusModal" data-toggle="modal" data-id="<?= $tpasien['id_pasien'];  ?>"><span class="badge badge-pill badge-danger">Hapus</span></a> | -->
                                            <a href="<?= base_url('admin/cetak_kib/' .  $tpasien['id_pasien']) ?>" target="_blank"><span class="badge badge-pill badge-light">Cetak KIB</span></a>
                                        </td>
                                        <td><?= $tpasien['nama']; ?></td>
                                    </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Content Row -->
</div>
<!-- /.container-fluid -->

<!-- Modal Hapus  -->
<div class="modal fade" id="hapusModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Apakah data ingin dihapus ?</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">No</button>
                <a class="btn btn-danger" id="btn-yes" href="">Yes</a>
            </div>
        </div>
    </div>
</div>

<script>
</script>