<!-- Begin Page Content -->
<div class="container-fluid">

  <?php if ($this->session->flashdata('message')) : ?>
    <?= $this->session->flashdata('message') ?>
  <?php endif ?>
  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Edit Pendaftaran</h1>
  </div>

  <div class="card">
    <div class="alert bg-success" role="alert">
      <h4 class="text-center text-light">Edit Pendaftaran</h4>
    </div>
    <div class="card-body">
      <form method="post" action="<?= base_url('admin/update_pendaftaran/' . $id); ?>">
        <div class="form-row">
          <div class="form-group col-md-6">
            <label>No Rm</label>
            <input type="text" class="form-control" value="<?= $pasien->norm ?>" readonly>
          </div>
          <div class="form-group col-md-6">
            <label>Nama Pasien</label>
            <input type="text" class="form-control" value="<?= $pasien->nama_p ?>" readonly>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label>Poli</label>
            <select class="form-control" name="id_spesialis">
              <option selected disabled>Poli</option>
              <?php foreach ($spesialis as $s) : ?>
                <option value="<?= $s->id_spesialis ?>" <?= $s->id_spesialis === $pendaftaran->id_spesialis ? 'selected' : '' ?>><?= $s->nama_spesialis ?></option>
              <?php endforeach ?>
            </select>
          </div>
          <div class="form-group col-md-6">
            <label>Dokter</label>
            <select class="form-control" name="id_dokter">
              <option selected disabled>Dokter</option>
              <?php foreach ($dokter as $d) : ?>
                <option value="<?= $d->id_dokter ?>" <?= $d->id_dokter === $pendaftaran->id_dokter ? 'selected' : '' ?>><?= $d->nama_d ?></option>
              <?php endforeach ?>
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label>Keluhan Pasien</label>
            <textarea class="form-control" name="keluhan" rows="5" placeholder="Keluhan"><?= $pendaftaran->keluhan ?></textarea>
          </div>
          <div class="form-group col-md-6">
            <label>Tanggal Daftar</label>
            <div class="date">
              <input type="date" class="form-control datepicker" name="tanggal_daftar" value="<?= $pendaftaran->tanggal_daftar ?>">
            </div>
          </div>
        </div><div class="form-row">
          <div class="form-group col-md-6">
            <label>Cara Bayar</label>
            <select class="form-control" name="cara_bayar">
              <option selected disabled>Pilih Cara Bayar</option>
              <option value="umum" <?= $pendaftaran->cara_bayar === 'umum' ? 'selected' : '' ?>>Umum</option>
              <option value="bpjs" <?= $pendaftaran->cara_bayar === 'bpjs' ? 'selected' : '' ?>>BPJS</option>
            </select>
          </div>
        </div>
        <button type="submit" class="btn btn-success">Update Data</button>
      </form>
    </div>
  </div>
  <!-- Content Row -->
</div>
<!-- /.container-fluid -->