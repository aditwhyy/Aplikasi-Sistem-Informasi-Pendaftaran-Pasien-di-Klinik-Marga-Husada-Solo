<!-- Begin Page Content -->
<div class="container-fluid">
  <!-- Page Heading -->
  <?php if ($this->session->flashdata('message')) : ?>
    <?= $this->session->flashdata('message') ?>
  <?php endif ?>
  <!-- Content Row -->
  <div class="row">
    <!-- Form -->
    <div class="col-md-3">
      <div class="card">
        <div class="alert bg-success" role="alert">
          <h4 class="text-center text-light">Form Registrasi</h4>
        </div>
        <div class="card-body">
          <form method="post" action="<?= base_url('admin/input_daftar') ?>">
            <div class="form-row">
              <div class="form-group col-md-12">
                <label>Daftar Pasien</label>
                <select class="form-control" name="id_pasien">
                  <option selected disabled>Pilih Pasien</option>
                  <?php foreach ($pasien as $p) : ?>
                    <option value="<?= $p->id_pasien ?>"><?= $p->norm ?> - <?= $p->nama_p ?></option>
                  <?php endforeach ?>
                </select>
              </div>
              <div class="form-group col-md-12">
                <label>Poli</label>
                <select class="form-control" name="id_spesialis">
                  <option selected disabled>Pilih Poli</option>
                  <?php foreach ($spesialis as $s) : ?>
                    <option value="<?= $s->id_spesialis ?>"><?= $s->nama_spesialis ?></option>
                  <?php endforeach ?>
                </select>
              </div>
              <div class="form-group col-md-12">
                <label>Dokter</label>
                <select class="form-control" name="id_dokter">
                  <option selected disabled>Pilih Dokter</option>
                  <?php foreach ($dokter as $d) : ?>
                    <option value="<?= $d->id_dokter ?>"><?= $d->nama_d ?></option>
                  <?php endforeach ?>
                </select>
              </div>
              <div class="form-group col-md-12">
                <label>Keluhan Pasien</label>
                <textarea class="form-control" name="keluhan" rows="2" placeholder="Keluhan"></textarea>
              </div>
              <div class="form-group col-md-12">
                <label>Tanggal Daftar</label>
                <div class="date">
                  <input type="date" class="form-control datepicker" name="tanggal_daftar" value="<?= date('Y-m-d') ?>" max="<?= date('Y-m-d') ?>" min="<?= date('Y-m-d') ?>" readonly>
                </div>
              </div>
              <div class="form-group col-md-12">
                <label>Cara Bayar</label>
                <select class="form-control" name="cara_bayar">
                  <option selected disabled>Pilih Cara Bayar</option>
                  <option value="umum">umum</option>
                  <option value="bpjs">bpjs</option>
                  <option value="umum">Umum</option>
                  <option value="bpjs">BPJS</option>
                </select>
              </div>
              <button type="submit" class="btn btn-success">Simpan Data</button>
            </div>
          </form>
        </div>
      </div>
    </div>
<!-- Table -->
<div class="col-md-9">
  <div class="card">
    <div class="alert bg-success" role="alert">
      <h4 class="text-center text-light">Table Pendaftaran Pasien</h4>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="background-color: yellow;">No</th>
              <!-- <th>Id Pasien</th> -->
              <th style="background-color: yellow;">No. RM </th>
              <th style="background-color: yellow;">Nama</th>
              <th style="background-color: yellow;">Keluhan</th>
              <th style="background-color: yellow;">Poli</th>
              <th style="background-color: yellow;">Dokter</th>
              <th style="background-color: yellow;">Tanggal</th>
              <th style="background-color: yellow;">Cara Bayar</th>
              <th style="background-color: yellow;">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            // Sort the data by id_daftar in descending order
            usort($list, function($a, $b) {
              return $b->id_daftar - $a->id_daftar;
            });
            foreach ($list as $index => $patient) :?>
              <tr class="<?=! $patient->nama_d? 'alert-warning' : ''?>">
                <td><?= $index + 1?></td>
                <!-- <td><?= $patient->id_pasien?></td> -->
                <td><?= $patient->norm?></td>
                <td><?= $patient->nama_p?></td>
                <td><?= $patient->keluhan?></td>
                <td><?= $patient->nama_spesialis?></td>
                <td><?= $patient->nama_d?></td>
                <td><?= $patient->tanggal_daftar?></td>
                <td><?= $patient->cara_bayar?></td>
                <td>
                  
                  <a href="<?= base_url('admin/edit_pendaftaran/'). $patient->id_daftar?>"><span class="badge badge-pill badge-primary">Edit</span></a> |
                  <a href="" class="hapusModalPendaftaran" data-target="#hapusModal" data-toggle="modal" data-id="<?= $patient->id_daftar?>"><span class="badge badge-pill badge-danger">Hapus</span></a>
                </td>
              </tr>
            <?php endforeach?>
            
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<hr>
<!-- Content Row -->
</div>

<!-- Modal Hapus  -->
<div class="modal fade" id="hapusModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Apakah data ingin dihapus ?</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">No</button>
        <a class="btn btn-danger" id="btn-yes" href="">Yes</a>
      </div>
    </div>
  </div>
</div>

<script>
  $(document).ready(function () {
    $('.hapusModalPendaftaran').on('click', function() {
      const id = $(this).data('id');
      let href = '<?= base_url('admin/hapus_pendaftaran/') ?>' + id
      $('#btn-yes').attr('href', href);
    });
  })
</script>
<!-- /.container-fluid -->