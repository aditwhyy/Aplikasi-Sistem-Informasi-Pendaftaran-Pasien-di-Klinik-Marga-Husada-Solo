<?php

  $pdf = new FPDF('L', 'cm', [9, 6]);

  $logo = FCPATH . 'assets/img/logoMH.jpeg';

  $pdf->AddPage();
  $pdf->Image($logo, 0.5, 0.5, 1.6, 2);

  $pdf->SetFont('Times', 'B', 12);
  $pdf->Text(2.75, 1, 'Kartu Identitas Berobat');
  $pdf->SetFont('Times', 'B', 7);

  $pdf->Text(3.25, 1.6, 'Klinik Marga Husada Surakarta');
  $pdf->Text(2.5, 2, 'Ijin klinik no. : 449.4/L-0033/L-08/IOK/X/2020');
  $pdf->Text(2.5, 2.4, 'JL K.H Agus Salim No.2 Surakarta Telp.716795');

  $pdf->SetLineWidth(0.02);
  $pdf->Line(0.5, 2.7, 8.5, 2.7);
  $pdf->SetLineWidth(0.07);
  $pdf->Line(0.5, 2.8, 8.5, 2.8);

  $pdf->SetFont('Times');
  
  $pdf->Text(0.8, 3.2, 'No. RM');
  $pdf->Text(0.8, 3.5, 'Nama Pasien');
  $pdf->Text(0.8, 3.8, 'Tanggal Lahir');
  $pdf->Text(0.8, 4.1, 'No. Telp');
  $pdf->Text(0.8, 4.4, 'Alamat');

  $pdf->Text(2.8, 3.2, ':');
  $pdf->Text(2.8, 3.5, ':');
  $pdf->Text(2.8, 3.8, ':');
  $pdf->Text(2.8, 4.1, ':');
  $pdf->Text(2.8, 4.4, ':');

  $pdf->Text(3, 3.2, $pasien->norm);
  $pdf->Text(3, 3.5, $pasien->nama_p);
  $pdf->Text(3, 3.8, $pasien->tanggal_lahir_p);
  $pdf->Text(3, 4.1, $pasien->notelp_p);
  $pdf->Text(3, 4.4, $pasien->alamat_p);

  $pdf->SetFont('Times', 'BI', 7);
  $pdf->Text(0.8, 5.1, 'BAWALAH KARTU INI SAAT BEROBAT');
  
  $pdf->SetFont('Times');
  $pdf->SetFontSize(6);
  $pdf->Text(0.8, 5.4, 'Melayani : Berobat Umum, Pemeriksaan Gigi, Khitan, Fisioterapi Massage Baby');
  $pdf->Text(0.8, 5.65, 'Vaksin Umroh');

  $pdf->Output('I', sprintf('KIB-%s.pdf', $pasien->nama_p));
