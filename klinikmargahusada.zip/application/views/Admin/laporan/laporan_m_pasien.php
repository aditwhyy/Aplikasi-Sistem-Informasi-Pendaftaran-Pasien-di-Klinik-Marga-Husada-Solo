<?php
$pdf = new PDF_MC_Table('P', 'mm', 'Letter');

$image1 = FCPATH . 'assets/img/logoMH.jpeg';

$pdf->AddPage();
$gambar1 = $pdf->Image($image1, 10, 4, 23);
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 7, 'Laporan Pasien', 0, 1, 'C');
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 7, 'Klinik Marga Husada Surakarta', 0, 1, 'C');
$pdf->Cell(0, 7, 'Ijin klinik no. : 449.4/L-0033/L-08/IOK/X/2020', 0, 1, 'C');
$pdf->Cell(0, 7, 'JL K.H Agus Salim No.2 Surakarta Telp.716795', 0, 1, 'C');
$pdf->Cell(0, 7, '', 0, 7);
$pdf->Ln(-2);

$x1 = 10;
$y1 = 10;
$x2 = 10;
$y2 = 10;

$pdf->SetLineWidth(0);
$pdf->Line(12, 40, 205, 40);
$pdf->SetLineWidth(1);
$pdf->Line(12, 41, 205, 41);
$pdf->SetLineWidth(0);
$pdf->Ln(5);
if (isset($tanggal1)) {
    $pdf->Ln(-4);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(0, 10, 'Laporan Pasien Tanggal ' . convertToIndonesianDate($tanggal1), 0, 1, 'C');
} elseif (isset($bulan)) {
    $pdf->Ln(-4);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(0, 10, 'Laporan Pasien Bulan ' . indonesianMonths($bulan) . ' ' . $tahun, 0, 1, 'C');
} elseif (isset($tahun)) {
    $pdf->Ln(-4);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(0, 10, 'Di Tahun ' . $tahun, 0, 1, 'C');
}
$pdf->SetFont('Arial', 'B', 10);

$pdf->Cell(0, 10, 'Tanggal Cetak Laporan : ' . convertToIndonesianDate(date('Y-m-d')), 0, 1, 'R');
$pdf->Cell(8, 6, 'No', 1, 0, 'C');
$pdf->Cell(20, 6, 'No. RM', 1, 0, 'C');
$pdf->Cell(35, 6, 'Nama Pasien', 1, 0, 'C');
// $pdf->Cell(10, 6, 'Umur', 1, 0, 'C');
$pdf->Cell(25, 6, 'Tanggal Lahir', 1, 0, 'C');
$pdf->Cell(25, 6, 'Notelp', 1, 0, 'C');
$pdf->Cell(40, 6, 'Alamat', 1, 0, 'C');
$pdf->Cell(35, 6, 'Petugas', 1, 1, 'C');

$pdf->SetWidths([8, 20, 35, 25, 25, 40, 35]);
$pdf->SetAligns(['C', 'C', 'C', 'C', 'C', 'C', 'C']);

$pdf->SetFont('Arial', '', 10);
$no = 1;
foreach ($pasien as $data) {
    $data = (object) $data;
    $pdf->Row([
        $no,
        $data->norm,
        $data->nama_p,
        // $data->umur_p,
        $data->tanggal_lahir_p,
        $data->notelp_p,
        $data->alamat_p,
        $data->nama,
    ]);
    $no++;
}

$pdf->Ln(14);
$pdf->Cell(0, 10, 'Surakarta, ' . convertToIndonesianDate(date('Y-m-d')), 0, 1, 'R');
$pdf->Ln(12);
$pdf->Cell(0, 10, $nama, 0, 1, 'R');

$pdf->Output();
