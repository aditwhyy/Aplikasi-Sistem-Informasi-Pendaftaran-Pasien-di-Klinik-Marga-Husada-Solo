<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Pendaftaran Pasien Online</title>

  <link href="<?= base_url('assets/vendor/fontawesome-free/css/all.min.css') ?>" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="<?= base_url('assets/css/sb-admin-2.min.css');?>" rel="stylesheet">
  <style>
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }

    input[type=number] {
      -moz-appearance: textfield;
      appearance: textfield;
    }

    .card {
      height: 36rem;
    }
  </style>
</head>

<body class="bg-gradient-success">

  <div class="container vh-100 d-flex align-items-center justify-content-center">
    <div class="row w-100">
      <div class="col-lg-12">
        <div class="card o-hidden border-0 shadow-lg">
          <div class="card-body p-0 overflow-auto">
            <div class="row">
              <div class="col-lg-12">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Input Data Pasien</h1>
                      <?= $this->session->flashdata('message') ?>
                  </div>
                  <hr>
                  <form action="<?= base_url('daftar/store');?>" method="post">
                    <!-- Jenis Pasien -->
                    <div class="form-group row">
                      <label class="col-sm-12 col-md-3 col-lg-2 col-form-label">Jenis Pasien</label>
                      <div class="col-sm-12 col-md-9 col-lg-6">
                        <div class="form-check">
                          <input class="form-check-input" type="radio" name="jenis_pasien" value="baru" id="pasienBaru" checked>
                          <label class="form-check-label" for="pasienBaru">
                            Baru
                          </label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="radio" name="jenis_pasien" value="lama" id="pasienLama">
                          <label class="form-check-label" for="pasienLama">
                            Lama
                          </label>
                        </div>
                      </div>
                    </div>

                    <!-- No RM -->
                    <div class="form-group row">
                      <label class="col-sm-12 col-md-3 col-lg-2 col-form-label">No RM</label>
                      <div class="col-sm-12 col-md-9 col-lg-6">
                        <div class="input-group mb-2">
                          <input type="text" class="form-control" id="norm" name="norm" placeholder="No RM" value="<?= $latestRM ?>" readonly>
                          <div class="input-group-append">
                            <button class="input-group-text bg-info text-light" type="button" id="cariDataPasien" disabled>Cari Data</button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- Nama Pasien -->
                    <div class="form-group row">
                      <label class="col-sm-12 col-md-3 col-lg-2 col-form-label">Nama Pasien</label>
                      <div class="col-sm-12 col-md-9 col-lg-6">
                        <div class="input-group mb-2">
                          <input type="text" class="form-control" name="nama_p" placeholder="Nama Pasien">
                        </div>
                      </div>
                    </div>

                    <!-- Umur Pasien -->
                    <div class="form-group row">
                      <label class="col-sm-12 col-md-3 col-lg-2 col-form-label">Umur Pasien</label>
                      <div class="col-sm-12 col-md-9 col-lg-6">
                        <div class="input-group mb-2">
                          <input type="number" class="form-control" name="umur_p" placeholder="Umur Pasien">
                          <div class="p-2">tahun</div>
                        </div>
                      </div>
                    </div>

                    <!-- Tanggal Lahir -->
                    <div class="form-group row">
                      <label class="col-sm-12 col-md-3 col-lg-2 col-form-label">Tanggal Lahir</label>
                      <div class="col-sm-12 col-md-9 col-lg-6">
                        <div class="input-group mb-2">
                          <input type="date" class="form-control" name="tanggal_lahir_p" placeholder="Tanggal Lahir" max="<?= date('Y-m-d') ?>">
                        </div>
                      </div>
                    </div>

                    <!-- Alamat -->
                    <div class="form-group row">
                      <label class="col-sm-12 col-md-3 col-lg-2 col-form-label">Alamat</label>
                      <div class="col-sm-12 col-md-9 col-lg-6">
                        <div class="input-group mb-2">
                          <textarea class="form-control" name="alamat_p" placeholder="Alamat"></textarea>
                        </div>
                      </div>
                    </div>

                    <!-- Jenis Kelamin -->
                    <div class="form-group row">
                      <label class="col-sm-12 col-md-3 col-lg-2 col-form-label">Jenis Kelamin</label>
                      <div class="col-sm-12 col-md-9 col-lg-6">
                        <div class="form-check">
                          <input class="form-check-input" type="radio" name="jenis_kelamin_p" value="laki-laki" id="lakilaki" checked>
                          <label class="form-check-label" for="lakilaki">
                            Laki - laki
                          </label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="radio" name="jenis_kelamin_p" value="perempuan" id="perempuan">
                          <label class="form-check-label" for="perempuan">
                            Perempuan
                          </label>
                        </div>
                      </div>
                    </div>

                    <!-- NIK -->
                    <div class="form-group row">
                      <label class="col-sm-12 col-md-3 col-lg-2 col-form-label">NIK</label>
                      <div class="col-sm-12 col-md-9 col-lg-6">
                        <div class="input-group mb-2">
                          <input type="number" class="form-control" name="nik" placeholder="NIK" maxlength="16">
                        </div>
                      </div>
                    </div>

                    <!-- Tanggal Periksa -->
                    <div class="form-group row">
                      <label class="col-sm-12 col-md-3 col-lg-2 col-form-label">Tanggal Periksa</label>
                      <div class="col-sm-12 col-md-9 col-lg-6">
                        <div class="input-group mb-2">
                          <input type="date" class="form-control" name="tanggal" placeholder="Tanggal Periksa">
                        </div>
                      </div>
                    </div>

                    <!-- Poli -->
                    <div class="form-group row">
                      <label class="col-sm-12 col-md-3 col-lg-2 col-form-label">Poli</label>
                      <div class="col-sm-12 col-md-9 col-lg-6">
                        <div class="input-group mb-2">
                          <select name="poli" class="form-control">
                            <?php foreach ($poli as $p) : ?>
                              <option value="<?= $p['id_spesialis'] ?>"><?= $p['nama_spesialis'] ?></option>
                            <?php endforeach ?>
                          </select>
                        </div>
                      </div>
                    </div>

                    <hr>

                    <button type="submit" class="btn btn-success btn-user btn-block">
                      Daftar
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="<?= base_url('assets/vendor/jquery/jquery.min.js') ?>"></script>
  <script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?= base_url('assets/vendor/jquery-easing/jquery.easing.min.js') ?>"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?= base_url('assets/js/sb-admin-2.min.js') ?>"></script>

  <script>
    $(document).ready(function() {
      $('input[type=radio][name=jenis_pasien]').click(function() {
        if (this.value == 'baru') {
          $('input[name=norm]').val('<?= $norm ?>').prop('readonly', true)
          $('input[name=nama_p]').val('').prop('readonly', false)
          $('input[name=umur_p]').val('').prop('readonly', false)
          $('input[name=tanggal_lahir_p]').val('').prop('readonly', false)
          $('textarea[name=alamat_p]').val('').prop('readonly', false)
          $('input[name=nik]').val('').prop('readonly', false)
          $('select[name=poli]').val('').prop('readonly', false)

          $('#cariDataPasien').prop('disabled', true).addClass('disabled')

        } else if (this.value == 'lama') {
          $('input[name=norm]').val('').prop('readonly', false)
          $('input[name=nama_p]').val('').prop('readonly', true)
          $('input[name=umur_p]').val('').prop('readonly', true)
          $('input[name=tanggal_lahir_p]').val('').prop('readonly', true)
          $('textarea[name=alamat_p]').val('').prop('readonly', true)
          $('input[name=nik]').val('').prop('readonly', true)
          $('select[name=poli]').val('').prop('readonly', true)

          $('#cariDataPasien').prop('disabled', false).removeClass('disabled')
        }
      })

      $('#cariDataPasien').click(function () {
        let norm = $('input[name=norm]').val()
        if (norm == '') {
          alert('No RM tidak boleh kosong')
          return
        }

        $.ajax({
          url: '<?= base_url('daftar/cari_data_pasien') ?>',
          type: 'POST',
          data: { norm },
          dataType: 'json',
          success: function (response) {
            alert('Data pasien ditemukan')
            let data = response.data
            
            if (response.status == 'success') {
              $('input[name=nama_p]').val(data.nama_p).prop('readonly', true)
              $('input[name=umur_p]').val(data.umur_p).prop('readonly', true)
              $('input[name=tanggal_lahir_p]').val(data.tanggal_lahir_p).prop('readonly', true)
              $('textarea[name=alamat_p]').val(data.alamat_p).prop('readonly', true)
              
              if (data.jenis_kelamin_p == 'laki-laki') {
                $('#lakilaki').prop('checked', true)
                $('#perempuan').prop('checked', false)
              } else {
                $('#perempuan').prop('checked', true)
                $('#lakilaki').prop('checked', false)
              }
              $('input[name=nik]').val(data.nik).prop('readonly', true)
              
            } else {
              alert('Data pasien tidak ditemukan')
            }
          }
        })
      })
    })
  </script>
</body>

</html>
