# Selamat Datang Di Aplikasi Klinikmargahusada v1.0
ADIT WAHYU RITAMA (210205043)
Ini adalah aplikasi pendaftaran pasien yang saya buat sebagai salah satu syarat untuk kelulusan (Tugas Akhir) dari prodi D3 Rekam Medis dan Informasi Kesehatan di Universitas Duta Bangsa Surakarta dengan tujuan untuk mempermudah pelayanan di klinik Marga Husada Surakarta.

Aplikasi ini dibuat menggunakan :
  1. PHP Codeigniter 3
  2. CSS Boostrap 3
  3. Template SB Admin 2
  4. Beberapa Plugin seperti js datepicker, fpdf untuk laporan, datatables boostrap dan lain lain

Aplikasi ini juga mempunyai 2 Hak akses: 
  1. Pimpinan klinik
  2. Admin/petugas pendaftaran

Gambaran dari aplikasi ini ialah dibawah ini

<img src="images/1.jpeg">
<br>
<hr>
<img src="images/2.jpeg">
<br>
<hr>
<img src="images/3.jpeg">
<br>
<hr>
<img src="images/4.jpeg">

Aplikasi ini baru mencapai tahap awal setelah selesai dibuat, lebih tepatnya klinikmargahusada v1.0
Emmm aplikasi ini masih belum sempurna sih msh ada bagian yg belum sempat saya perbaiki, jadi silahkan download jika kalian mau mengembangkan lebih lanjut 
kalo ada kendala pas mau uji coba. DM IG @aditttwhyy_
